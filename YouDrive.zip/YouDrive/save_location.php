<?php
    include 'includes/config.php';  
    $client_id = $_POST['client_id'];
    $pickup = $_POST['pickup'];
    $destination = $_POST['destination'];

    $query = "UPDATE client SET pickup='$pickup' , destination='$destination' WHERE client_id=$client_id";
    $conn->query($query);
    header('location: pay.php');

?>