<?php
	include 'includes/config.php';
	$id = $_REQUEST['id'];
		$query = "UPDATE client SET status='Approved' WHERE `client_id`=6";
	$result = $conn->query($query);
	if($result === TRUE){
		echo "<script type = \"text/javascript\">
					alert(\"Message Successfully Send\");
					window.location = (\"adminIndex.php\")
				</script>";
	}
?>
