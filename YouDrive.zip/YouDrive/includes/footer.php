	<li class="about">
					<p>For a Safe Journey</p>
					<ul>
						<li><a href="" target="_blank"></a></li>
						<li><a href="" class="twitter" target="_blank"></a></li>
						<li><a href="" class="google" target="_blank"></a></li>
						<li><a href="#" class="skype"></a></li>
					</ul>
				</li>
			</ul>
		</div>

		<div class="copyrights wrapper">
			
		</div>
	</footer><!--  end footer  -->
	
</body>
</html>