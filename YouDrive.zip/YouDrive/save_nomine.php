<?php
    include 'includes/config.php';
    $name = $_POST['name'];
    $phone_num = $_POST['phone_num'];
    $nid = $_POST['nid'];
    $address = $_POST['address'];

    $query = "INSERT INTO `nominee`(`name`, `phone_number`, `nid`, `address`) VALUES ('$name','$phone_num', '$nid', '$address')";
    $conn->query($query);
    echo "<script type = \"text/javascript\">
        alert(\"Payment Successfully Done. Wait for Admin Approval\");
        
        </script>";
    header('location:wait.php');
?>